package com.aura.launcher

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppEntry(
    val pkg: String,
    val label: String,
    val intent: Intent,
    val image: ImageBitmap,
    val isBanner: Boolean,
    val tint: Color,
)

object AppRepository {

    /** Loads installed apps off the main thread; images are decoded once and kept as bitmaps. */
    suspend fun load(ctx: Context): List<AppEntry> = withContext(Dispatchers.Default) {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()

        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val info = ri.activityInfo ?: continue
                val pkg = info.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue

                val banner = info.loadBanner(pm) ?: info.applicationInfo?.loadBanner(pm)
                val isBanner = banner != null
                val drawable = banner ?: ri.loadIcon(pm)
                val bmp = if (isBanner) drawable.toBitmap(320, 180) else drawable.toBitmap(192, 192)

                val swatch = Palette.from(bmp).maximumColorCount(8).generate().let {
                    it.vibrantSwatch ?: it.dominantSwatch
                }
                val base = swatch?.rgb ?: 0xFF2A3350.toInt()
                val tint = Color(ColorUtils.blendARGB(base, 0xFF000000.toInt(), 0.35f))

                out += AppEntry(
                    pkg = pkg,
                    label = ri.loadLabel(pm).toString(),
                    intent = Intent(Intent.ACTION_MAIN)
                        .addCategory(category)
                        .setClassName(pkg, info.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                    image = bmp.asImageBitmap(),
                    isBanner = isBanner,
                    tint = tint,
                )
            }
        }
        out.sortedBy { it.label.lowercase() }
    }
}
